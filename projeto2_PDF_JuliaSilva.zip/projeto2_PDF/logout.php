<?php
//logout.php
require_once 'config.php';

//Destrói a sessão
session_destroy();

//Redireciona para login
header('Location:login.php');
exit;
?>