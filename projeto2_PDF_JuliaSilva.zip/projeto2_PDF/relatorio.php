<?php
// relatorio.php
require_once 'config.php'; // <-- ponto e vírgula corrigido

// Inclui a biblioteca FPDF
require_once ('C:\xampp\htdocs\projeto2_PDF\fpdf\fpdf.php');

// Verifica autenticação
if(!isset($_SESSION['usuario_id'])){
    header('Location: login.php');
    exit;
}

// Cria o PDF
class PDF extends FPDF {
    function Header(){
        $this->SetFont('Arial','B',15);
        $this->Cell(0,10,utf8_decode('Relatório de Produtos'),0,1,'C');
        $this->Ln(10);
    }

    function Footer(){
        $this->SetY(-15);
        $this->SetFont('Arial','I',8);
        $this->Cell(0,10,'Pagina '.$this->PageNo(),0,0,'C');
    }
}

$pdo = conectarBanco(); // Correção: o nome da função é conectarBanco(), não conectaBanco()
$pdf = new PDF();
$pdf->AddPage();
$pdf->SetFont('Arial','',12);

// Cabeçalho da tabela
$pdf->SetFillColor(200,220,255);
$pdf->Cell(10,10,utf8_decode('ID'),1,0,'C',true);
$pdf->Cell(50,10,utf8_decode('Nome'),1,0,'C',true);
$pdf->Cell(80,10,utf8_decode('Descrição'),1,0,'C',true);
$pdf->Cell(20,10,utf8_decode('Estoque'),1,0,'C',true);
$pdf->Cell(30,10,utf8_decode('Valor Unitário'),1,1,'C',true);

// Dados dos produtos
$stmt = $pdo->query("SELECT * FROM produto");
$fill = false;

while($produto = $stmt->fetch(PDO::FETCH_ASSOC)){
    $descricao = mb_strimwidth($produto['descricao'], 0, 40, '...');

    $pdf->SetFillColor(240,240,240);
    $pdf->Cell(10,10,utf8_decode($produto['id_produto']),1,0,'C',$fill);
    $pdf->Cell(50,10,utf8_decode($produto['nome_prod']),1,0,'L',$fill);
    $pdf->Cell(80,10,utf8_decode($descricao),1,0,'L',$fill);
    $pdf->Cell(20,10,utf8_decode($produto['qtde']),1,0,'C',$fill); // Corrigido largura da célula para 20
    $pdf->Cell(30,10,'R$'.number_format($produto['valor_unit'],2,',','.'),1,1,'R',$fill);
    $fill = !$fill; // <-- Corrigido: faltava ponto e vírgula
}
$pdf->Cell(10,10,'Julia R Silva');


// Saída do PDF
$pdf->Output('relatorio_produtos.pdf', 'I');
?>
