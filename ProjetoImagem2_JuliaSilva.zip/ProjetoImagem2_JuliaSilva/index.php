<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <title>Início</title>
    <link rel="stylesheet" href="styles.css">
</head>
<body>
    <div class="menu-container">
        <select onchange="location = this.value;">
            <option selected disabled>Menu</option>
            <option value="index.php">Início</option>
            <option value="cadastro_funcionario.php">Cadastrar Funcionário</option>
            <option value="consultar_funcionario.php">Consultar Funcionário</option>
            <option value="visualizar_funcionario.php">Visualizar Funcionário</option>
        </select>
    </div>