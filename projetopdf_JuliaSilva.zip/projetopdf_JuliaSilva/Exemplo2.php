<?php
echo "Julia Rodrigues Silva";
//Inicia o buffer de saida para capturar qualquer conteudo
ob_start();

//Inclui o autoload do composer 
require_once ('C:\xampp\htdocs\projetopdf_JuliaSilva\fpdf\fpdf.php');

class NOVOPDF extends FPDF{
    function Header(){

        //Insere imagem
        $this->Image('logo.png',5,1,50);

        //Pula 30 pontos abaixo da imagem
        $this->Ln(30);

        //Define a fonte: Arial, nregrito, tmanho 15
        $this->SetFont('Arial','B',15);

        //Move cursor 80 pontos para direita
        $this->Cell(80);
        $this->Cell(30,10, iconv('UTF-8','ISO-8859-1//TRANSLIT','Título'),1,0,'C');

        //Pula 12 pontos pra baixo
        $this->Ln(20);
    }

    //Rodape personalizado
    function Footer(){
        //Posição vertical a 15 pontos do fim da pagina
        $this->SetY(-15);

        //Fonte arial, italico
        $this->SetFont('Arial','I',8);
        //nuemro da pagina
        $this->Cell(0,10,'Página'.$this->PageNo().'/{nb} - Julia Rodrigues Silva',0,0,'C');

       
    }
}

 //Cria o pdf usando a classe personalizada
 $pdf=new NOVOPDF();

 //Ativa o uso do {nb} para total de paginas no rodape
 $pdf->AliasNbPages();

 //Adiciona primeira pagina
 $pdf->AddPage();

 //Corpo do documento

 //Define fonte para o conteudo do corpo
 $pdf->SetFont('Times','',12);

 //Gera 80 linhas com conteudo simulado
 for($i=1;$i<=80;$i++){
    //Largura total, altura 10, sem borda, quebra de linha
    $pdf->Cell(0,10,'Teste de linha'.$i,0,1);
 }

 $pdf->Output();

?>